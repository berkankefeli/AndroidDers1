package com.example.lab08.customlistviewkullanimi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<PhoneModel> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview);

        arrayList.add(
                new PhoneModel(1,"Şerif","0212 000 11 22","https://i0.wp.com/ozhanozturk.com/wp-content/uploads/2017/09/yin-and-yang-simgeler-semboller.png?fit=720%2C720")
        );
        arrayList.add(
                new PhoneModel(1,"Ben","0212 000 11 33","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTt3Pm9XlUBTdm9qhgQdUesLJ5c6bvgHWdMGTbpx78nCXrnLdL1Tw")
        );


        listView = (ListView)findViewById(R.id.listView);
        ListViewAdapter adapter = new ListViewAdapter(getApplicationContext(),arrayList);
        listView.setAdapter(adapter);
    }
}
