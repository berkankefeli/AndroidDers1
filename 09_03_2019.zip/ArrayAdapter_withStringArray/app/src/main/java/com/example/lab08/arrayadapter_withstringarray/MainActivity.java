package com.example.lab08.arrayadapter_withstringarray;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView listview;
    ArrayAdapter<String> adapter;

    String[] ulkeler = {"Türkiye","Irak","Avustralya","İspanya","Suriye","Arabistan","İtalya"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listview = findViewById(R.id.listview);

        adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,ulkeler);
        listview.setAdapter(adapter);



    }
}
