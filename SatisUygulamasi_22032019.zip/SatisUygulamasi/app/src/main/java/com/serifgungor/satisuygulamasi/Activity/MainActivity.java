package com.serifgungor.satisuygulamasi.Activity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.serifgungor.satisuygulamasi.Adapter.AdapterKategori;
import com.serifgungor.satisuygulamasi.Helper.DatabaseHelper;
import com.serifgungor.satisuygulamasi.Model.Kategori;
import com.serifgungor.satisuygulamasi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    GridView kategoriler;
    AdapterKategori adapterKategori;
    ArrayList<Kategori> kat = new ArrayList<>();
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    Cursor c;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        kategoriler = findViewById(R.id.gridViewKategoriler);

        try{
            dbHelper = new DatabaseHelper(getApplicationContext());
            dbHelper.createDatabase();
            db = dbHelper.getReadableDatabase();
            c = db.rawQuery("Select * from Kategori order by id ",null);
            while(c.moveToNext()){

                kat.add(new Kategori(
                        c.getInt(c.getColumnIndex("id")),
                        c.getString(c.getColumnIndex("ad")),
                        c.getString(c.getColumnIndex("resim"))));

            }

        }catch(Exception e){
            Log.e("DB_LOG",e.getMessage());
            Log.e("DB_LOG","Veritabanı oluşturulamadı veya kopyalanamadı !");
        }





        adapterKategori = new AdapterKategori(kat,getApplicationContext());
        kategoriler.setAdapter(adapterKategori);


        kategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                Intent intent = new Intent(getApplicationContext(),AltKategoriActivity.class);
                intent.putExtra("kategori",kat.get(position));
                startActivity(intent);

            }
        });

    }
}
