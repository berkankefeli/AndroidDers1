package com.serifgungor.satisuygulamasi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.satisuygulamasi.Model.AltKategori;
import com.serifgungor.satisuygulamasi.R;

import java.util.ArrayList;

public class AdapterAltKategori extends BaseAdapter {
    private ArrayList<AltKategori> altKategoriler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterAltKategori() {
    }

    public AdapterAltKategori(ArrayList<AltKategori> altKategoriler, Context context) {
        this.altKategoriler = altKategoriler;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return altKategoriler.size();
    }

    @Override
    public AltKategori getItem(int position) {
        return altKategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.altkategori_satirgoruntusu,null);

        ImageView ivResim = v.findViewById(R.id.ivAltKategoriResim);
        TextView tvBaslik = v.findViewById(R.id.tvAltKategoriBaslik);
        TextView tvAciklama = v.findViewById(R.id.tvAltKategoriAciklama);

        tvBaslik.setText(altKategoriler.get(position).getKategoriAdi());
        tvAciklama.setText(altKategoriler.get(position).getKategoriAciklama());

        Glide
                .with(context)
                .load(altKategoriler.get(position).getKategoriResim())
                .into(ivResim);


        return v;
    }
}
