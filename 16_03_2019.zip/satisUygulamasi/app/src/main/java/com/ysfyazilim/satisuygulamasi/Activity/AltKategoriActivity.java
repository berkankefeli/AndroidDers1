package com.ysfyazilim.satisuygulamasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.ysfyazilim.satisuygulamasi.Adapter.AdapterAltKategori;
import com.ysfyazilim.satisuygulamasi.Adapter.AdapterKategori;
import com.ysfyazilim.satisuygulamasi.Model.AltKategori;
import com.ysfyazilim.satisuygulamasi.Model.Kategori;
import com.ysfyazilim.satisuygulamasi.R;

import java.util.ArrayList;

public class AltKategoriActivity extends AppCompatActivity {

    ListView altKategori;
    AdapterAltKategori adapterAltKategori;
    ArrayList<AltKategori> altKat = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alt_kategori);

        //Bir önceki sayfadan doğrudan bir nesneyi 2. sayfaya taşımak istiyorsak gönderdiğimiz objectin serializable türünde olması gerekir.

        Kategori kategori = (Kategori)getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getAd());

        altKategori = findViewById(R.id.listViewAltKategoriler);

        if(kategori.getId()==1) {

            altKat.add(new AltKategori(1, 1, "Ekipmanlar", "http://fr" +
                    "agtist.com/wp-content/uploads/2015/01/fragtist-strix-set-inceleme-17.jpg", "Mouse,klavye,kulaklık..."));
            altKat.add(new AltKategori(2, 1, "Bilgisayar Bileşenleri", "https://img.," +
                    "tamindir.com/ti_e_ul/canerdil/Bilgisayar-Toplama-ile-ilgili-Dikkate-Almamaniz-Gereken-6-Efsane-4.jpg", "Ekran kartı,işlemci,RAM,Anakart..."));
        }else if(kategori.getId()==2){
            altKat.add(new AltKategori(1,2,"Erkek Giyim","","Erkek Kazak,Gömlek,T-shirt..."));
            altKat.add(new AltKategori(2,2,"Kadın Giyim","","Kadın Kazak,Gömlek,T-shirt..."));
            altKat.add(new AltKategori(3,2,"Çocuk Giyim","","Çocuk Kazak,Gömlek,T-shirt..."));


        }
        adapterAltKategori = new AdapterAltKategori(altKat,getApplicationContext());
        altKategori.setAdapter(adapterAltKategori);
        altKategori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),UrunlerActivity.class);
                intent.putExtra("altKategori",altKat.get(position));
                startActivity(intent);


            }
        });








    }
}
