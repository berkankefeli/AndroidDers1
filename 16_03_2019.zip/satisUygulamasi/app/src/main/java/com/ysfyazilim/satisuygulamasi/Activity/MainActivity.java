package com.ysfyazilim.satisuygulamasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.GridView;

import com.ysfyazilim.satisuygulamasi.Adapter.AdapterKategori;
import com.ysfyazilim.satisuygulamasi.Model.Kategori;
import com.ysfyazilim.satisuygulamasi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    GridView kategoriler;
    AdapterKategori adapterKategori;
    ArrayList<Kategori> kat = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        kategoriler = findViewById(R.id.gridViewKategoriler);

        kat.add(new Kategori(1,"Bilgisayar","https://productimages.hepsiburada.net/s/19/552/9843894747186.jpg?v1"));
        kat.add(new Kategori(2,"Giyim","https://productimages.hepsiburada.net/s/19/552/9843894747186.jpg?v1"));
        kat.add(new Kategori(3,"Beyaz Eşya","https://productimages.hepsiburada.net/s/19/552/9843894747186.jpg?v1"));
        kat.add(new Kategori(4,"Mobilya","https://productimages.hepsiburada.net/s/19/552/9843894747186.jpg?v1"));

        adapterKategori = new AdapterKategori(kat,getApplicationContext());
        kategoriler.setAdapter(adapterKategori);
        kategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),AltKategoriActivity.class);
                intent.putExtra("kategori",kat.get(position));
                startActivity(intent);
            }
        });


    }
}
