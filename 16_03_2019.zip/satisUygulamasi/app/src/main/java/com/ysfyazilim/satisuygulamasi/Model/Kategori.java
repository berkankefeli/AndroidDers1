package com.ysfyazilim.satisuygulamasi.Model;

import java.io.Serializable;

public class Kategori implements Serializable {

    private int id;
    private String Ad;
    private String Resim;
    public Kategori() {

    }

    public Kategori(int id, String ad, String resim) {
        this.id = id;
        Ad = ad;
        Resim = resim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAd() {
        return Ad;
    }

    public void setAd(String ad) {
        Ad = ad;
    }

    public String getResim() {
        return Resim;
    }

    public void setResim(String resim) {
        Resim = resim;
    }
}
