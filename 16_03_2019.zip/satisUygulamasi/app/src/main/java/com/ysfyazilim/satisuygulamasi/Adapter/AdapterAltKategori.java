package com.ysfyazilim.satisuygulamasi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.ysfyazilim.satisuygulamasi.Model.AltKategori;
import com.ysfyazilim.satisuygulamasi.R;

import java.util.ArrayList;

public class AdapterAltKategori extends BaseAdapter{

    private ArrayList<AltKategori> altKategori;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterAltKategori() {
    }

    public AdapterAltKategori(ArrayList<AltKategori> altKategori, Context context) {
        this.altKategori = altKategori;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return altKategori.size();
    }

    @Override
    public AltKategori getItem(int position) {
        return altKategori.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.altkategori_goruntusu,null);
        ImageView iv = v.findViewById(R.id.ivAltKategoriResim);
        TextView tv1 = v.findViewById(R.id.tvAltKategoriBaslik);
        TextView tv2 = v.findViewById(R.id.tvAltKategoriAciklama);

        tv1.setText(altKategori.get(position).getKategoriAdi());
        tv2.setText(altKategori.get(position).getKategoriAciklama());
        Glide.with(context).load(altKategori.get(position).getKategoriResim()).into(iv);

        return v;
    }
}
