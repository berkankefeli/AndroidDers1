package com.ysfyazilim.satisuygulamasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ysfyazilim.satisuygulamasi.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        new Bekle().start();

    }
    private class Bekle extends Thread{
        @Override
        public void run() {
            super.run();
            try{
                Thread.sleep(5000);

            }
            catch (Exception e){

            }
            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent);
            finish();


        }
    }

}
