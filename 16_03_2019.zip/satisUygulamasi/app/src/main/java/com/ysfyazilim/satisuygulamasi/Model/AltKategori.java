package com.ysfyazilim.satisuygulamasi.Model;

import java.io.Serializable;

public class AltKategori implements Serializable{

    private int id;
    private int ustKategoriId;
    private String kategoriAdi;
    private String kategoriResim;
    private String kategoriAciklama;

    public AltKategori() {
    }

    public AltKategori(int id, int ustKategoriId, String kategoriAdi, String kategoriResim, String kategoriAciklama) {
        this.id = id;
        this.ustKategoriId = ustKategoriId;
        this.kategoriAdi = kategoriAdi;
        this.kategoriResim = kategoriResim;
        this.kategoriAciklama = kategoriAciklama;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUstKategoriId() {
        return ustKategoriId;
    }

    public void setUstKategoriId(int ustKategoriId) {
        this.ustKategoriId = ustKategoriId;
    }

    public String getKategoriAdi() {
        return kategoriAdi;
    }

    public void setKategoriAdi(String kategoriAdi) {
        this.kategoriAdi = kategoriAdi;
    }

    public String getKategoriResim() {
        return kategoriResim;
    }

    public void setKategoriResim(String kategoriResim) {
        this.kategoriResim = kategoriResim;
    }

    public String getKategoriAciklama() {
        return kategoriAciklama;
    }

    public void setKategoriAciklama(String kategoriAciklama) {
        this.kategoriAciklama = kategoriAciklama;
    }
}
