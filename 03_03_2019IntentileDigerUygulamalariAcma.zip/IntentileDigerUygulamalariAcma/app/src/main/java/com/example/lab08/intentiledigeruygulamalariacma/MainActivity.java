package com.example.lab08.intentiledigeruygulamalariacma;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnCall,btnGo,btnSend,btnOps,btnMap,btnSendEmail;
    EditText etPhoneNumber,etWebSite,etSms,etSmsNumber,etEmail,etTitle,etMailContent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etMailContent = findViewById(R.id.etMailContent);
        btnSendEmail = findViewById(R.id.btnSendEmail);
        etEmail = findViewById(R.id.etEmail);
        etTitle = findViewById(R.id.etTitle);
        btnMap = findViewById(R.id.btnMap);
        btnOps = findViewById(R.id.btnOps);
        btnSend = findViewById(R.id.btnSend);
        etSmsNumber = findViewById(R.id.etSmsNumber);
        etSms = findViewById(R.id.etSms);
        btnGo = findViewById(R.id.btnGo);
        etWebSite = findViewById(R.id.etWebSite);
        btnCall = findViewById(R.id.btnCall);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("tel:"+etPhoneNumber.getText().toString());
                i.setData(uri);
                startActivity(i);

            }
        });
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("http://"+etWebSite.getText().toString());
                i.setData(uri);
                startActivity(i);
            }
        });

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SENDTO);
                Uri uri = Uri.parse("sms:"+etSmsNumber.getText().toString());
                i.putExtra("sms_body",etSms.getText().toString());
                i.setData(uri);
                startActivity(i);


            }
        });

        btnOps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("market://details?id=com.whatsapp"));
                    startActivity(intent);
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),"Google Play Store app not found",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse("geo:0,0?q=41.008583,28.980175")));
            }
        });

        btnSendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/html");
                    intent.putExtra(Intent.EXTRA_EMAIL,etEmail.getText().toString());
                    intent.putExtra(Intent.EXTRA_SUBJECT,etTitle.getText().toString());
                    intent.putExtra(Intent.EXTRA_TEXT,etMailContent.getText().toString());
                    startActivity(Intent.createChooser(intent,"Choose App"));
                }catch (Exception e){

                }
            }
        });


    }
}
