package com.example.lab08.baseadapterkullanimi.Model;

public class Meyve {

    private String ad;
    private int resim;


    public Meyve() {
    }

    public Meyve(String ad, int resim) {
        this.ad = ad;
        this.resim = resim;
    }

        public String getAd() {
            return ad;
        }

        public void setAd(String ad) {
            this.ad = ad;
        }

        public int getResim() {
            return resim;
        }

        public void setResim(int resim) {
            this.resim = resim;
        }
}
