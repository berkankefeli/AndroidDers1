package com.example.lab08.baseadapter_2.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.lab08.baseadapter_2.Adapter.AdapterTakimlar;
import com.example.lab08.baseadapter_2.Model.Takimlar;
import com.example.lab08.baseadapter_2.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Takimlar> takimlar= new ArrayList<>();
    AdapterTakimlar adapterTakimlar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listview);

        takimlar.add(new Takimlar("Trabzonspor", R.drawable.ts));
        takimlar.add(new Takimlar("Beşiktaş", R.drawable.bjk));
        takimlar.add(new Takimlar("Erzurumspor", R.drawable.erz));
        takimlar.add(new Takimlar("Kayserispor", R.drawable.kys));
        takimlar.add(new Takimlar("Akhisarspor", R.drawable.aks));

        adapterTakimlar = new AdapterTakimlar(takimlar,getApplicationContext());
        listView.setAdapter(adapterTakimlar);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),"Tıklanan Takım: "+takimlar.get(position).getTakimAdi(),Toast.LENGTH_LONG).show();

                Intent intent = new Intent(getApplicationContext(),OyuncularActivity.class).putExtra("takim_adi",takimlar.get(position).getTakimAdi());
                startActivity(intent);

            }
        });




    }
}
