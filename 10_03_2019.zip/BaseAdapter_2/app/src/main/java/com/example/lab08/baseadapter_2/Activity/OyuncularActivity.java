package com.example.lab08.baseadapter_2.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.lab08.baseadapter_2.Adapter.AdapterOyuncu;
import com.example.lab08.baseadapter_2.Model.Oyuncu;
import com.example.lab08.baseadapter_2.R;

import java.util.ArrayList;


public class OyuncularActivity extends AppCompatActivity {

    ListView listview;
    AdapterOyuncu adapteroyuncu;
    ArrayList<Oyuncu> oyuncular= new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyuncular);

        String takim = getIntent().getStringExtra("takim_adi");
        setTitle(takim);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //toolbara geri butonunu ekler

        listview = findViewById(R.id.lvOyuncular);

        if("Trabzonspor".equals(takim)){
            oyuncular.add(new Oyuncu(1,"Yusuf Yazici","yusuf",20,10));
            oyuncular.add(new Oyuncu(2,"Abdulkadir Omur","abdus",18,61));
            oyuncular.add(new Oyuncu(3,"Sosa","sosa",30,8));
            oyuncular.add(new Oyuncu(4,"Anthony Nwakaeme","nwakaeme",30,99));
        }else if("Beşiktaş".equals(takim)){
            oyuncular.add(new Oyuncu(1,"Babel","babel",24,10));
            oyuncular.add(new Oyuncu(2,"Loris Karius","karius",25,1));
        }

        adapteroyuncu = new AdapterOyuncu(oyuncular,getApplicationContext());
        listview.setAdapter(adapteroyuncu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==android.R.id.home){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}
