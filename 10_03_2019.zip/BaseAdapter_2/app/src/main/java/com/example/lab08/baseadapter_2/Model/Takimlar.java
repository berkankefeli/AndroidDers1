package com.example.lab08.baseadapter_2.Model;

public class Takimlar {

    private String takimAdi;
    private int resim;

    public Takimlar() {
    }

    public Takimlar(String takimAdi, int resim) {
        this.takimAdi = takimAdi;
        this.resim = resim;
    }

    public String getTakimAdi() {
        return takimAdi;
    }

    public void setTakimAdi(String takimAdi) {
        this.takimAdi = takimAdi;
    }

    public int getResim() {
        return resim;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }
}
