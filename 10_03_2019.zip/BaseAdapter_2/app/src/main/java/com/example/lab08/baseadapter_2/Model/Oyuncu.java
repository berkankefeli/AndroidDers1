package com.example.lab08.baseadapter_2.Model;

public class Oyuncu {

    private int id;
    private String adSoyad;
    private String resim;
    private int yas;
    private int formaNo;

    public Oyuncu() {
    }

    public Oyuncu(int id, String adSoyad, String resim, int yas, int formaNo) {
        this.id = id;
        this.adSoyad = adSoyad;
        this.resim = resim;
        this.yas = yas;
        this.formaNo = formaNo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAdSoyad() {
        return adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }

    public int getFormaNo() {
        return formaNo;
    }

    public void setFormaNo(int formaNo) {
        this.formaNo = formaNo;
    }
}
