package com.example.lab08.baseadapter_2.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lab08.baseadapter_2.Model.Takimlar;
import com.example.lab08.baseadapter_2.R;

import java.util.ArrayList;

public class AdapterTakimlar extends BaseAdapter{

    private ArrayList<Takimlar> takimlar;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterTakimlar() {
    }

    public AdapterTakimlar(ArrayList<Takimlar> takimlar, Context context) {
        this.takimlar = takimlar;
        this.context = context;
        this.layoutInflater =(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return takimlar.size();
    }

    @Override
    public Takimlar getItem(int position) {
        return takimlar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.takim_satirgoruntusu,null);

        ImageView ivResim = v.findViewById(R.id.ivTakim);
        TextView tvBaslik = v.findViewById(R.id.tvAdi);

        tvBaslik.setText(takimlar.get(position).getTakimAdi());
        ivResim.setImageResource(takimlar.get(position).getResim());




        return v;
    }
}
