package com.example.firebasedatabasekullanimi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.example.firebasedatabasekullanimi.Adapter.AdapterOgrenci;
import com.example.firebasedatabasekullanimi.Model.Ogrenci;
import com.example.firebasedatabasekullanimi.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Ogrenci> ogrenciler = new ArrayList<>();
    AdapterOgrenci adapterOgrenci;
    ListView listView;

    public void ogrenciEkle (Ogrenci ogrenci){
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference().child("ogrenciler");
        dbRef.push().setValue(
                new Ogrenci(
                        ogrenci.getOgrenciNo(),
                        ogrenci.getAdSoyad(),
                        ogrenci.getTelefonNo(),
                        ogrenci.getTcNo(),
                        ogrenci.getOkul(),
                        ogrenci.getBolum(),
                        ogrenci.getOkulaGirisYili()
                )
        );
    }

    public ArrayList<Ogrenci> ogrencileriCagir(){
        final ArrayList<Ogrenci> ogrenciler  = new ArrayList<>();

        myRef.child("ogrenciler").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ogrenciler.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Ogrenci ogrenci = snapshot.getValue(Ogrenci.class);
                    ogrenciler.add(
                            new Ogrenci(
                                    ogrenci.getOgrenciNo(),
                                    ogrenci.getAdSoyad(),
                                    ogrenci.getTelefonNo(),
                                    ogrenci.getTcNo(),
                                    ogrenci.getOkul(),
                                    ogrenci.getBolum(),
                                    ogrenci.getOkulaGirisYili()
                            )
                    );
                }
                adapterOgrenci = new AdapterOgrenci(ogrenciler,getApplicationContext());
                listView.setAdapter(adapterOgrenci);

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {}

        });

        return ogrenciler;
    }

    FirebaseDatabase database;
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference();
        listView = findViewById(R.id.lvOgrenci);

        Ogrenci ogrenci1 = new Ogrenci();
        ogrenci1.setAdSoyad("Berkan KEFELİ");
        ogrenci1.setBolum("EHM");
        ogrenci1.setOgrenciNo(1111);
        ogrenci1.setOkul("YTÜ");
        ogrenci1.setOkulaGirisYili(2015);
        ogrenci1.setTcNo(111);
        ogrenci1.setTelefonNo("12123123");

        ogrenciEkle(ogrenci1);

        ogrenciler = ogrencileriCagir();
        adapterOgrenci = new AdapterOgrenci(ogrenciler,getApplicationContext());
        listView.setAdapter(adapterOgrenci);





















     /*   FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");

        myRef.setValue("Hello, World!");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                Log.d("FIND", "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("FIND", "Failed to read value.", error.toException());
            }
        });*/



    }
}
