package com.serifgungor.mp3playerapp.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.serifgungor.mp3playerapp.Model.Eser;
import com.serifgungor.mp3playerapp.R;

import java.util.ArrayList;

public class SarkilarActivity extends AppCompatActivity {
    ListView listViewSarkilar;
    ArrayList<Eser> eserler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sarkilar);

        listViewSarkilar = findViewById(R.id.listViewSarkilar);
        eserler = new ArrayList<>();
    }
}
