package com.serifgungor.mp3playerapp.Helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import com.serifgungor.mp3playerapp.Model.Album;
import com.serifgungor.mp3playerapp.Model.Eser;
import com.serifgungor.mp3playerapp.Model.MuzikKategori;
import com.serifgungor.mp3playerapp.Model.Sanatci;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "mp3database.db";
    //Tabloların her biri, static stringler ile üretildi.
    private static final String TABLO_SANATCI = "Sanatci";
    private static final String TABLO_ESER = "Eser";
    private static final String TABLO_ALBUM = "Album";
    private static final String TABLO_MUZIK_KATEGORI = "MuzikKategori";
    //Sanatci Tablosu kolon isimleri
    private static final String TBL_SANATCI_ID = "sanatciId";
    private static final String TBL_SANATCI_KATEGORIID = "kategoriId";
    private static final String TBL_SANATCI_ADSOYAD = "sanatciAdSoyad";
    private static final String TBL_SANATCI_DOGUMYILI = "sanatciDogumYili";
    private static final String TBL_SANATCI_DIL = "sanatciDil";
    private static final String TBL_SANATCI_ULKE = "sanatciUlke";
    private static final String TBL_SANATCI_ACIKLAMA = "sanatciAciklama";
    private static final String TBL_SANATCI_RESIM = "sanatciResim";
    //Eser Tablosu kolon isimleri
    private static final String TBL_ESER_ID = "eserId";
    private static final String TBL_ESER_ALBUMID = "albumId";
    private static final String TBL_ESER_SANATCIID = "sanatciId";
    private static final String TBL_ESER_ADI = "eserAdi";
    private static final String TBL_ESER_ACIKLAMA = "eserAciklama";
    private static final String TBL_ESER_YAYINYILI = "yayinYili";
    private static final String TBL_ESER_GORSEL = "eserGorseli";
    private static final String TBL_ESER_MP3DOSYAADRESI = "mp3DosyaAdresi";
    //Album Tablosu kolon isimleri
    private static final String TBL_ALBUM_ID = "albumId";
    private static final String TBL_ALBUM_ADI = "albumAdi";
    private static final String TBL_ALBUM_ACIKLAMA = "albumAciklama";
    private static final String TBL_ALBUM_SANATCIID = "sanatciId";
    private static final String TBL_ALBUM_CIKISTARIHI = "cikisTarihi";
    //MuzikKategori Tablosu kolon isimleri
    private static final String TBL_MUZIK_KATEGORI_ID = "kategoriId";
    private static final String TBL_MUZIK_KATEGORI_ADI = "kategoriAdi";
    private static final String TBL_MUZIK_KATEGORI_RESIM = "kategoriResim";
    private HashMap hp;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        /*
        Veritabanının üretilme zamanını temsil etmektedir.

        db.execSQL() metodu, insert update delete ve create sorguları için kullanılır.
        db.rawQuery() metodu ise, select sorguları için kullanılır.
        db.insert, db.update,db.delete,Cursor,
         */

        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLO_SANATCI + " (" + TBL_SANATCI_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + TBL_SANATCI_KATEGORIID + " INTEGER," + TBL_SANATCI_ADSOYAD + " VARCHAR," + TBL_SANATCI_DOGUMYILI + " INTEGER," + TBL_SANATCI_DIL + " VARCHAR(25)," + TBL_SANATCI_ULKE + " VARCHAR(75)," + TBL_SANATCI_ACIKLAMA + " TEXT," + TBL_SANATCI_RESIM + " TEXT)");

        StringBuilder muzikKategori = new StringBuilder();
        muzikKategori.append("CREATE TABLE IF NOT EXISTS " + TABLO_MUZIK_KATEGORI + " (");
        muzikKategori.append(TBL_MUZIK_KATEGORI_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,");
        muzikKategori.append(TBL_MUZIK_KATEGORI_ADI + " VARCHAR,");
        muzikKategori.append(TBL_MUZIK_KATEGORI_RESIM + " TEXT)");
        db.execSQL(muzikKategori.toString());


        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLO_ALBUM + " (" + TBL_ALBUM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + TBL_ALBUM_ADI + " VARCHAR," + TBL_ALBUM_ACIKLAMA + " TEXT," + TBL_ALBUM_SANATCIID + " INTEGER," + TBL_ALBUM_CIKISTARIHI + " VARCHAR(25))");


        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLO_ESER + " (" + TBL_ESER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + TBL_ESER_ALBUMID + " INTEGER," + TBL_ESER_SANATCIID + " INTEGER," + TBL_ESER_ADI + " VARCHAR," + TBL_ESER_ACIKLAMA + " TEXT," + TBL_ESER_YAYINYILI + " INTEGER," + TBL_ESER_GORSEL + " TEXT," + TBL_ESER_MP3DOSYAADRESI + " TEXT)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       /*
       Veritabanının güncellenme zamanını temsil eder.
        */
        db.execSQL("DROP TABLE IF EXISTS contacts");
        onCreate(db);
    }

    public boolean tabloyaVeriEkle(String tabloAdi, ContentValues contentValues) {
        SQLiteDatabase db = this.getWritableDatabase();
        /*
        Tabloya veri eklenirken adı bilinen bir kolona key-value formatında değer ataması yapar.
        Yani key -> kolon adı, value -> eklenecek değer.
         */
        db.insert(tabloAdi, null, contentValues);
        return true;
    }

    public Cursor satiriGetir(String tabloAdi, String kolonAdi, String deger) {
        /*
        Cursor sınıfı veritabanından select sorgusundan dönen tüm sonuçları gezmek için kullanılır.
         */
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + tabloAdi + " where " + kolonAdi + "='" + deger + "'", null);
        return res;
    }

    public Cursor satiriGetir(String tabloAdi, String kolonAdi, int deger) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + tabloAdi + " where " + kolonAdi + "=" + deger, null);
        return res;
    }

    public Cursor verileriGetir(String sorgu) { // select * from User
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery(sorgu, null);
        return res;
    }


    public int satirSayisiniDon(String tabloAdi) {
        // Belirli tablodaki satır sayısını döner
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, tabloAdi);
        return numRows;
    }

    public int satirSayisiniDon_sorguyaGore(String sorgu) {
        //select * from Users where cinsiyet='e'
        //20 sonuç varsa
        SQLiteDatabase db = this.getReadableDatabase();
        int satirSayisi = 0;
        Cursor c = db.rawQuery(sorgu, null);
        satirSayisi = c.getCount();
        return satirSayisi; //20 dönecektir.
    }


    public boolean satiriGuncelle(String tabloAdi, String whereClause, String[] whereArgs, ContentValues cv) {
        //Uyeler,id,String[]{"1"},cv
        SQLiteDatabase db = this.getWritableDatabase();
        db.update(tabloAdi, cv, whereClause, whereArgs);
        return true;
    }

    public boolean satiriGuncelle(String tabloAdi, String whereClause, ContentValues cv) {
        //Uyeler,id=1,cv
        SQLiteDatabase db = this.getWritableDatabase();
        db.update(tabloAdi, cv, whereClause, null);
        return true;
    }

    public int satiriSil(String tabloAdi, String whereClause) {
        //Uyeler, id=1
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(tabloAdi, whereClause, null);
    }

    public ArrayList<Sanatci> getTumSanatcilar(int kategoriId) {
        /*
        Argüman olarak hangi tablo Adını belirtmiş isek, ilgili tablodaki tüm sonuçları
        bu metot içerisinde bizim belirlediğimiz tipte dönüş sağlayabilen bir yapı ürettik.
         */
        ArrayList<Sanatci> array_list = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLO_SANATCI + " where "+TBL_SANATCI_KATEGORIID+"="+kategoriId, null);

            while (res.moveToNext()){
                array_list.add(new Sanatci(
                        res.getInt(res.getColumnIndex(TBL_SANATCI_ID)),
                        res.getInt(res.getColumnIndex(TBL_SANATCI_KATEGORIID)),
                        res.getString(res.getColumnIndex(TBL_SANATCI_ADSOYAD)),
                        res.getInt(res.getColumnIndex(TBL_SANATCI_DOGUMYILI)),
                        res.getString(res.getColumnIndex(TBL_SANATCI_DIL)),
                        res.getString(res.getColumnIndex(TBL_SANATCI_ULKE)),
                        res.getString(res.getColumnIndex(TBL_SANATCI_ACIKLAMA)),
                        res.getString(res.getColumnIndex(TBL_SANATCI_RESIM))
                ));
            }

        return array_list;
    }

    public ArrayList<Eser> getTumEserler() {
        ArrayList<Eser> array_list = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLO_ESER, null);

            while (res.moveToNext()){
                array_list.add(new Eser(
                        res.getInt(res.getColumnIndex(TBL_ESER_ID)),
                        res.getInt(res.getColumnIndex(TBL_ESER_ALBUMID)),
                        res.getInt(res.getColumnIndex(TBL_ESER_SANATCIID)),
                        res.getString(res.getColumnIndex(TBL_ESER_ADI)),
                        res.getString(res.getColumnIndex(TBL_ESER_ACIKLAMA)),
                        res.getInt(res.getColumnIndex(TBL_ESER_YAYINYILI)),
                        res.getString(res.getColumnIndex(TBL_ESER_GORSEL)),
                        res.getString(res.getColumnIndex(TBL_ESER_MP3DOSYAADRESI))
                ));
            }

        /*


        } else if (TABLO_ALBUM.equals(tabloAdi)) {
            //int albumId, String albumAdi, String albumAciklama, int sanatciId, String cikisTarihi
            if(res.moveToFirst()){
                while (res.moveToNext()){
                    array_list.add(new Album(
                            res.getInt(res.getColumnIndex(TBL_ALBUM_ID)),
                            res.getString(res.getColumnIndex(TBL_ALBUM_ADI)),
                            res.getString(res.getColumnIndex(TBL_ALBUM_ACIKLAMA)),
                            res.getInt(res.getColumnIndex(TBL_ALBUM_SANATCIID)),
                            res.getString(res.getColumnIndex(TBL_ALBUM_CIKISTARIHI))
                    ));
                }
            }

        } else if (TABLO_MUZIK_KATEGORI.equals(tabloAdi)) {
            //int kategoriId, String kategoriAdi, String kategoriResim
            if(res.moveToFirst()){
                while (res.moveToNext()){
                    array_list.add(new MuzikKategori(
                            res.getInt(res.getColumnIndex(TBL_MUZIK_KATEGORI_ID)),
                            res.getString(res.getColumnIndex(TBL_MUZIK_KATEGORI_ADI)),
                            res.getString(res.getColumnIndex(TBL_MUZIK_KATEGORI_RESIM))
                    ));
                }
            }
        }
        */
        return array_list;
    }

    public ArrayList<Album> getTumAlbumler() {
        ArrayList<Album> array_list = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLO_ALBUM, null);


            while (res.moveToNext()){
                array_list.add(new Album(
                        res.getInt(res.getColumnIndex(TBL_ALBUM_ID)),
                        res.getString(res.getColumnIndex(TBL_ALBUM_ADI)),
                        res.getString(res.getColumnIndex(TBL_ALBUM_ACIKLAMA)),
                        res.getInt(res.getColumnIndex(TBL_ALBUM_SANATCIID)),
                        res.getString(res.getColumnIndex(TBL_ALBUM_CIKISTARIHI))
                ));
            }

        /*

        } else if (TABLO_MUZIK_KATEGORI.equals(tabloAdi)) {
            //int kategoriId, String kategoriAdi, String kategoriResim
            if(res.moveToFirst()){
                while (res.moveToNext()){
                    array_list.add(new MuzikKategori(
                            res.getInt(res.getColumnIndex(TBL_MUZIK_KATEGORI_ID)),
                            res.getString(res.getColumnIndex(TBL_MUZIK_KATEGORI_ADI)),
                            res.getString(res.getColumnIndex(TBL_MUZIK_KATEGORI_RESIM))
                    ));
                }
            }
        }
        */
        return array_list;
    }
    public ArrayList<MuzikKategori> getTumKategoriler() {
        ArrayList<MuzikKategori> array_list = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLO_MUZIK_KATEGORI, null);

            while (res.moveToNext()){
                array_list.add(new MuzikKategori(
                        res.getInt(res.getColumnIndex(TBL_MUZIK_KATEGORI_ID)),
                        res.getString(res.getColumnIndex(TBL_MUZIK_KATEGORI_ADI)),
                        res.getString(res.getColumnIndex(TBL_MUZIK_KATEGORI_RESIM))
                ));
            }


        return array_list;
    }

    /*
    db.insert
    db.update
    db.delete
    rawQuery
    execSql
    getReadableDatabase
    getWritableDatabase
    Cursor
    - moveToNext()
    - moveToFirst()
    - getInt
    - getString
    - getColumnIndex
     */
}