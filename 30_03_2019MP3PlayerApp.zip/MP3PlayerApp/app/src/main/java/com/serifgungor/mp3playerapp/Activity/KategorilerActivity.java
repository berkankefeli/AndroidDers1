package com.serifgungor.mp3playerapp.Activity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.serifgungor.mp3playerapp.Adapter.AdapterMuzikKategori;
import com.serifgungor.mp3playerapp.Helper.DBHelper;
import com.serifgungor.mp3playerapp.Model.MuzikKategori;
import com.serifgungor.mp3playerapp.R;

import java.util.ArrayList;

public class KategorilerActivity extends AppCompatActivity {

    ListView listViewKategoriler;
    ArrayList<MuzikKategori> kategoriler;
    DBHelper dbHelper;
    SQLiteDatabase db;
    AdapterMuzikKategori adapterMuzikKategori;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategoriler);

        listViewKategoriler = findViewById(R.id.listViewKategoriler);
        kategoriler = new ArrayList<>();

        dbHelper = new DBHelper(getApplicationContext());
        db = dbHelper.getReadableDatabase();
        dbHelper.onCreate(db); //veritabanını üret.


        int sonuc = dbHelper.satirSayisiniDon("MuzikKategori");
        if(sonuc==0){
            ContentValues cv = new ContentValues();
            cv.put("kategoriAdi","Pop");
            cv.put("kategoriResim","http://muzikonair.com/wp-content/uploads/2017/10/pop-muzik.jpg");
            dbHelper.tabloyaVeriEkle("MuzikKategori",cv);


            ContentValues cv1 = new ContentValues();
            cv1.put("kategoriAdi","Türkçe Müzik");
            cv1.put("kategoriResim","https://pbs.twimg.com/profile_images/636598669345746945/XrZRCVAZ_400x400.jpg");
            dbHelper.tabloyaVeriEkle("MuzikKategori",cv1);
        }

        kategoriler = dbHelper.getTumKategoriler();
        adapterMuzikKategori = new AdapterMuzikKategori(getApplicationContext(),kategoriler);
        listViewKategoriler.setAdapter(adapterMuzikKategori);

        listViewKategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),SanatcilarActivity.class);
                intent.putExtra("kategori",kategoriler.get(position));
                startActivity(intent);
            }
        });



    }
}
