package com.serifgungor.mp3playerapp.Activity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

import com.serifgungor.mp3playerapp.Adapter.AdapterSanatci;
import com.serifgungor.mp3playerapp.Helper.DBHelper;
import com.serifgungor.mp3playerapp.Model.MuzikKategori;
import com.serifgungor.mp3playerapp.Model.Sanatci;
import com.serifgungor.mp3playerapp.R;

import java.util.ArrayList;

public class SanatcilarActivity extends AppCompatActivity {

    GridView gridViewSanatcilar;
    ArrayList<Sanatci> sanatcilar;
    DBHelper dbHelper;
    SQLiteDatabase db;
    AdapterSanatci adapterSanatci;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sanatcilar);

        MuzikKategori muzikKategori = (MuzikKategori) getIntent().getSerializableExtra("kategori");

        dbHelper = new DBHelper(getApplicationContext());
        db = dbHelper.getReadableDatabase();


        int sonuc = dbHelper.satirSayisiniDon("Sanatci");
        if(sonuc==0){
            ContentValues cv = new ContentValues();
            cv.put("kategoriId",muzikKategori.getKategoriId());
            cv.put("sanatciAdSoyad","");
            cv.put("sanatciDogumYili","");
            cv.put("sanatciDil","");
            cv.put("sanatciUlke","");
            cv.put("sanatciAciklama","");
            cv.put("sanatciResim","");
            dbHelper.tabloyaVeriEkle("Sanatci",cv);


            ContentValues cv1 = new ContentValues();
            cv1.put("kategoriId",muzikKategori.getKategoriId());
            cv1.put("sanatciAdSoyad","");
            cv1.put("sanatciDogumYili","");
            cv1.put("sanatciDil","");
            cv1.put("sanatciUlke","");
            cv1.put("sanatciAciklama","");
            cv1.put("sanatciResim","");
            dbHelper.tabloyaVeriEkle("Sanatci",cv1);


        }


        gridViewSanatcilar = findViewById(R.id.gridViewSanatcilar);
        sanatcilar = dbHelper.getTumSanatcilar(muzikKategori.getKategoriId());



        adapterSanatci = new AdapterSanatci(getApplicationContext(),sanatcilar);
        gridViewSanatcilar.setAdapter(adapterSanatci);


    }
}

