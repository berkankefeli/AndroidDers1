package com.serifgungor.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.serifgungor.mp3playerapp.Model.Album;
import com.serifgungor.mp3playerapp.R;

import java.util.ArrayList;

public class AdapterAlbum extends BaseAdapter {
    private Context context;
    private ArrayList<Album> albumler;
    private LayoutInflater layoutInflater;

    public AdapterAlbum() {
    }

    public AdapterAlbum(Context context, ArrayList<Album> albumler) {
        this.context = context;
        this.albumler = albumler;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return albumler.size();
    }

    @Override
    public Object getItem(int position) {
        return albumler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.album_satirgoruntusu,null);

        TextView tvAlbumAdi,tvAlbumCikisTarihi,tvAlbumAciklama;
        tvAlbumAciklama = v.findViewById(R.id.tvAlbumAciklama);
        tvAlbumCikisTarihi = v.findViewById(R.id.tvAlbumCikisTarihi);
        tvAlbumAdi = v.findViewById(R.id.tvAlbumAdi);

        tvAlbumAdi.setText(albumler.get(position).getAlbumAdi());
        tvAlbumAciklama.setText(albumler.get(position).getAlbumAciklama());
        tvAlbumCikisTarihi.setText(albumler.get(position).getCikisTarihi());

        return v;

    }
}
