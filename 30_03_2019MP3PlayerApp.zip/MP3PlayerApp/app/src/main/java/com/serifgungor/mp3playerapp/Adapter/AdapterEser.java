package com.serifgungor.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.mp3playerapp.Model.Eser;
import com.serifgungor.mp3playerapp.R;

import java.util.ArrayList;

public class AdapterEser extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Eser> eserler;

    public AdapterEser() {
    }

    public AdapterEser(Context context, ArrayList<Eser> eserler) {
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.eserler = eserler;
    }

    @Override
    public int getCount() {
        return eserler.size();
    }

    @Override
    public Object getItem(int position) {
        return eserler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.eser_satirgoruntusu,null);
        ImageView ivEserResim;
        TextView tvEserBaslik,tvEserYayinYili,tvEserAciklama;

        ivEserResim = v.findViewById(R.id.ivEserResim);
        tvEserBaslik = v.findViewById(R.id.tvEserBaslik);
        tvEserAciklama = v.findViewById(R.id.tvEserAciklama);
        tvEserYayinYili = v.findViewById(R.id.tvEserYayinYili);

        Glide
                .with(context)
                .load(eserler.get(position).getEserGorseli())
                .into(ivEserResim);
        tvEserBaslik.setText(eserler.get(position).getEserAdi());
        tvEserAciklama.setText(eserler.get(position).getEserAciklama());
        tvEserYayinYili.setText(""+eserler.get(position).getYayinYili());

        return v;
    }
}
