package com.serifgungor.mp3playerapp.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.serifgungor.mp3playerapp.Model.Album;
import com.serifgungor.mp3playerapp.R;

import java.util.ArrayList;

public class AlbumActivity extends AppCompatActivity {

    ListView listViewAlbum;
    ArrayList<Album> albumler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album);

        listViewAlbum = findViewById(R.id.listViewAlbum);
        albumler = new ArrayList<>();
    }
}
