package com.serifgungor.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.mp3playerapp.Model.Sanatci;
import com.serifgungor.mp3playerapp.R;

import java.util.ArrayList;

public class AdapterSanatci extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Sanatci> sanatcilar;

    public AdapterSanatci() {
    }

    public AdapterSanatci(Context context, ArrayList<Sanatci> sanatcilar) {
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.sanatcilar = sanatcilar;
    }

    @Override
    public int getCount() {
        return sanatcilar.size();
    }

    @Override
    public Object getItem(int position) {
        return sanatcilar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.sanatci_satirgoruntusu,null);

        ImageView ivSanatciResim;
        TextView tvSanatciAdSoyad,tvSanatciDogumYili;

        ivSanatciResim = v.findViewById(R.id.ivSanatciResim);
        tvSanatciAdSoyad = v.findViewById(R.id.tvSanatciAdSoyad);
        tvSanatciDogumYili = v.findViewById(R.id.tvSanatciDogumYili);

        Glide
                .with(context)
                .load(sanatcilar.get(position).getSanatciResim())
                .into(ivSanatciResim);

        tvSanatciAdSoyad.setText(sanatcilar.get(position).getSanatciAdSoyad());
        tvSanatciDogumYili.setText(Integer.toString(sanatcilar.get(position).getSanatciDogumYili()));

        return v;
    }
}
