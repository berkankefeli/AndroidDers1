package com.serifgungor.mp3playerapp.Model;

import java.io.Serializable;

public class Sanatci implements Serializable {
    private int sanatciId;
    private int kategoriId;
    private String sanatciAdSoyad;
    private int sanatciDogumYili;
    private String sanatciDil;
    private String sanatciUlke;
    private String sanatciAciklama;
    private String sanatciResim;

    public Sanatci() {
    }

    public Sanatci(int sanatciId, int kategoriId, String sanatciAdSoyad, int sanatciDogumYili, String sanatciDil, String sanatciUlke, String sanatciAciklama, String sanatciResim) {
        this.sanatciId = sanatciId;
        this.kategoriId = kategoriId;
        this.sanatciAdSoyad = sanatciAdSoyad;
        this.sanatciDogumYili = sanatciDogumYili;
        this.sanatciDil = sanatciDil;
        this.sanatciUlke = sanatciUlke;
        this.sanatciAciklama = sanatciAciklama;
        this.sanatciResim = sanatciResim;
    }

    public int getSanatciId() {
        return sanatciId;
    }

    public void setSanatciId(int sanatciId) {
        this.sanatciId = sanatciId;
    }

    public int getKategoriId() {
        return kategoriId;
    }

    public void setKategoriId(int kategoriId) {
        this.kategoriId = kategoriId;
    }

    public String getSanatciAdSoyad() {
        return sanatciAdSoyad;
    }

    public void setSanatciAdSoyad(String sanatciAdSoyad) {
        this.sanatciAdSoyad = sanatciAdSoyad;
    }

    public int getSanatciDogumYili() {
        return sanatciDogumYili;
    }

    public void setSanatciDogumYili(int sanatciDogumYili) {
        this.sanatciDogumYili = sanatciDogumYili;
    }

    public String getSanatciDil() {
        return sanatciDil;
    }

    public void setSanatciDil(String sanatciDil) {
        this.sanatciDil = sanatciDil;
    }

    public String getSanatciUlke() {
        return sanatciUlke;
    }

    public void setSanatciUlke(String sanatciUlke) {
        this.sanatciUlke = sanatciUlke;
    }

    public String getSanatciAciklama() {
        return sanatciAciklama;
    }

    public void setSanatciAciklama(String sanatciAciklama) {
        this.sanatciAciklama = sanatciAciklama;
    }

    public String getSanatciResim() {
        return sanatciResim;
    }

    public void setSanatciResim(String sanatciResim) {
        this.sanatciResim = sanatciResim;
    }
}
