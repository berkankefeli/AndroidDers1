package com.serifgungor.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.mp3playerapp.Model.MuzikKategori;
import com.serifgungor.mp3playerapp.R;

import java.util.ArrayList;

public class AdapterMuzikKategori extends BaseAdapter {
    private Context context;
    private ArrayList<MuzikKategori> muzikKategorileri;
    private LayoutInflater layoutInflater;

    public AdapterMuzikKategori() {
    }

    public AdapterMuzikKategori(Context context, ArrayList<MuzikKategori> muzikKategorileri) {
        this.context = context;
        this.muzikKategorileri = muzikKategorileri;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return muzikKategorileri.size();
    }

    @Override
    public Object getItem(int position) {
        return muzikKategorileri.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
      View v = layoutInflater.inflate(R.layout.kategori_satirgoruntusu,null);

        ImageView ivKategoriResim;
        TextView tvKategoriBaslik;

        ivKategoriResim = v.findViewById(R.id.ivKategoriResim);
        tvKategoriBaslik = v.findViewById(R.id.tvKategoriBaslik);

        Glide
                .with(context)
                .load(muzikKategorileri.get(position).getKategoriResim())
                .into(ivKategoriResim);

        tvKategoriBaslik.setText(muzikKategorileri.get(position).getKategoriAdi());

      return v;
    }
}
