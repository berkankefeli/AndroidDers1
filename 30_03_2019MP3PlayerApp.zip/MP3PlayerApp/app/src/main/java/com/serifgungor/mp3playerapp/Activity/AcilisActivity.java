package com.serifgungor.mp3playerapp.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.serifgungor.mp3playerapp.R;

public class AcilisActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategoriler);
        new Acilis().start();
    }

    private class Acilis extends Thread{
        @Override
        public void run() {
            super.run();
            try{
                Thread.sleep(2000);
            }catch (Exception e){

            }
            startActivity(new Intent(getApplicationContext(),KategorilerActivity.class));
        }
    }
}
